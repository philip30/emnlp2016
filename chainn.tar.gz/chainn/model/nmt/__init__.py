from chainn.model.nmt.encdec import EncoderDecoder
from chainn.model.nmt.efattentional import Attentional
from chainn.model.nmt.dictattentional import DictAttentional
