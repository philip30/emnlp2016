from chainn.model.basic.mlp import MLP

