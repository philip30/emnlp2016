from chainn.machine.parallel_trainer import ParallelTrainer
from chainn.machine.tester import Tester
