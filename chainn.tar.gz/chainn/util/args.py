class Args(object):
    def __init__(self, args_dict):
        for k, v in args_dict.items():
            self.k = v

